// Your web app's Firebase configuration

 var firebaseConfig = {
    apiKey: "AIzaSyBYp3UZDATAUdG5x6T6ZOBx_3agJi6oOKY",
    authDomain: "elderly-hub-during-corvid19.firebaseapp.com",
    projectId: "elderly-hub-during-corvid19",
    storageBucket: "elderly-hub-during-corvid19.appspot.com",
    messagingSenderId: "156931586769",
    appId: "1:156931586769:web:37db37f45c6b43ccdb23f0",
    measurementId: "G-6JX51TYDXS"
  };

// Initialize Firebase  

firebase.initializeApp(firebaseConfig);
let database = firebase.database();

let name = document.getElementById("username");
let input = document.getElementById("message");

input.addEventListener('keypress', function(event) {
  if(event.key == "Enter") {
    database.ref("messages").push({
      name: name.value, 
      message: input.value
    })

    input.value="";
  }
})

database.ref("messages").on('child_added', function(message) {

  let messages = document.getElementById("messages");
  let name = message.val().name;
  let value = message.val().message;

  let div = document.createElement("div");
  let span = document.createElement("span");
  span.innerHTML = "@" + name;
  let p = document.createElement("p");
  p.innerHTML = value; 

  div.appendChild(span);
  div.appendChild(p);

  messages.appendChild(div);
  messages.scrollTop = messages.scrollHeight; 
})