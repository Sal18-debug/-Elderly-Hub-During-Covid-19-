# Quick Meals

Quick Meals serves personalized meals based on your set of criteria to make your time in the kitchen easier!

### Inspiration
When we were discussing our project, we saw that all of us are fond of the idea of cooking. Eventually, we started to brainstorm ways we can relate the topic of cooking with helping others. We understand for some of our peers, it could be difficult to prepare meals. They either don’t have the time, ingredients, or equipment, to do so. Others may want to look for meals that cater to their specific needs. Therefore, we decided to create a platform that gives an easy and fun way to discover new meals based on their criteria.  

### Technologies Used
- [Figma](https://www.figma.com/proto/eqoFJvB4V6c6KY1sgvzZJn/CreaticaProject?node-id=1%3A15&scaling=scale-down) for the prototype
- HTML/CSS/Bootstrap and JavaScript for the Front-End
- Adobe Illustrator and Procreate for graphics
- [FlatIcon](https://www.flaticon.com/) for additional assets

### How To Record Audio
https://medium.com/@bryanjenningz/how-to-record-and-play-audio-in-javascript-faa1b2b3e49b#:~:text=To%20start%20recording%20the%20audio,resolves%20to%20the%20audio%20stream.

Rapid api

https://rapidapi.com/edamam/api/edamam-food-and-grocery-database

Elderly Care During COVID-19!-
The global community is going through a hard time during this pandemic but the segment of society worst affected is the older generation.
Our Elderly Hub During Covid-19! helps older people to digitally fulfil their food needs via restaurants, groceries, recipes as well food and nutrition tips, food donation, covid-19 safety tips, face mask recognition and senior care alert device while they are alone home during pandemic, empathy, meet up groups and donation services for emergency items. They can also use online digital resources for mental peace, mood music and chat features for mental relaxation by providing support groups.

I am going to make a web application using HTML5, JavaScript, CSS and machine learning or AI.


# Feature Summary
## Restaurants Ordering - DONE
1. Firstly we want to use an API to list all the resturaunts in an area (close to where the user is): https://rapidapi.com/ptwebsolution/api/worldwide-restaurants?endpoint=apiendpoint_8bfaa5e8-45b8-42f2-a264-4428a99699df
2. The user then clicks on the resturaunt and needs to click on an "Order" button. Once the order button is clicked, the user will be prompted to allow access to his/her microphone (only the first time). The user can then speak their order and once completed click the "Stop Recording" button. Their voice recording will then be changed to text (Speedh - to - text) using an API (https://rapidapi.com/MelroseLabs/api/melrose-labs-voice-api1?endpoint=apiendpoint_3c922151-68fa-46a3-a5db-e70f10e4b698) which will then be sent to the resturaunt as an order

## Grocery Page - DONE
1. On the grocery page we want to take what we have on the support page (using an API to search for food) and change the code so that it is compatible with the grocery page. Instead of displaying the food in the table it will display the main result in the card format
2. Once they click on the card format, we will take them to the second page where they can see all the matching resutls and then add quantities of each to their card
3. Once they click on the cart they can see everything they selected
4. They can click on the checkout button that will take them to a page where they have to enter their address, name and email where the bill will be sent to 
5. When searching, users can comma seperate words and the api will search for multiple foods, example: apple, berry, banana, nut, etc

## Donate - DONE
1. Users can come to the donation page and enter their name and food items that they have available to donate. 
2. They can then click submit which will add the donated foods to the foodbank. 
3. Users can see a list of all foods in the foodbank and click on claim to claim the food for themself which will then also take the food off the foodbank list since it has been claimed

## Chat Feature - DONE
We can copy that firebase chat repl.it that we have used and looked at before

## Blog
Users can add blog posts in groups

## Alert System
Look into a free text messaging API

## Face Mask recognition
Find an API that can detect face masks

## Play Mood Music Based on Face




# RESEARCH
## COVID Alerts
### Purpose
We want do something different than what we have done before, research and learn new coding techniques and ideas related to COVID-19 screening.

Instead of the now very commonly used website that just asks for questions and tells you immidiately if you are at risk for COVID or not, we want to do a two stage screening process which will help the community more accurately identify if they have COVID or not since the evaluation will be based not only on a website quiz but on an actual doctors professional and medical opinion.

Another benefit will be that the transmission to the doctor will be immidiate (since we are using our self developed C# Web API Service) so the doctor can evaluate as soon as he/she sees the information and provide direct and fast feedback, medical support and advice.

### Method
We will achieve the above by a two step process as already mentioned. The steps are as follows:
1. Ask screening questions (this is already being done very widely and commonly)
2. Record audio and video to send to a doctor for evaluation (NEW!!!!)

We will then come up with a few dummy responses from a dummy doctor that will be sent back to the person's email and tell them some more information, we can also show an immidiate web alert based on the response from our API.

### Required research
1. Do research on some common COVID questions
2. Do research on how the results of these questions influence the risk assesement for the personalized
3. Do research and learn how to record audio and video from a website
4. Do research on how to encode/download these recordings to send to a doctor for evaluation
5. Do research on how this information will be sent to a doctor
6. Do research on where we can host a c# web service for free to receive the audio and video files that were recorded from the web page

### Technologies
1. HTML, CSS and JS for the questionare, audio and video recording
2. C# Web API Service for receiving the information from the web page (self developed)
3. A new dummy gmail account that will be used by the C# service to send emails to the people who record the audio and video