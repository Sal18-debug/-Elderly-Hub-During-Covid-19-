function claimDonatedItem(itemName){
	if (confirm('Are you sure you want to claim this item?')){
		//Make sure that the session storage exists
		if (window.sessionStorage.getItem("DonatedItems") != null){
			//Since the session storage exists, get all the items from the storage and assign them to a variable
			var donatedItems = JSON.parse(window.sessionStorage.getItem("DonatedItems"));

			//Create another variable which looks for the claimed item in the list of items
			var claimedItem = donatedItems.find(where => where.name == itemName)

			//Now get the index of the claimed item in the items list
			const index = donatedItems.indexOf(claimedItem);

			//Make sure the index is greater than -1 (indicating that it does in fact exist in the list)
			if (index > -1) {
				//Remove the item from the list
				donatedItems.splice(index, 1);
			}

			//Assign our list where the item has been removed from back to the session storage
			window.sessionStorage.setItem("DonatedItems", JSON.stringify(donatedItems));

			//Reload the page so that the items are loaded again and the removed item will be gone
			window.location.reload();
		}
	}
}

function donateItem(e){
	e.preventDefault();

	var txtDonateItem = document.getElementById('txtDonateItem');
	if (txtDonateItem.value == ''){
		alert('Please describe the item you want to donate');	
		return;
	}

	var htmlTemplate = '<div class="col-sm-4" style="text-align: center; border: 1px solid black; border-radius: 5px;padding:20px ;margin: 20px; background-color: white; width: 500px; height: 200px"><a href="javascript:claimDonatedItem(\'$itemName$\');"><img class="thumbpic" src="images/donate.png"><h3>$itemName$</h3></a></div>';

	var parentDiv = document.getElementById("parent-div");

	parentDiv.innerHTML += htmlTemplate.replaceAll('$itemName$', txtDonateItem.value);

	//Create an empty array variable which will be out array of donated items
	var donatedItems = [];

	//This IF checks if the session storage named "DonatedItems" already exists
	if (window.sessionStorage.getItem("DonatedItems") == null){
		//If it doesn't exist, lets create it and just set it to empty for now
		window.sessionStorage.setItem("DonatedItems", JSON.stringify([]));
	} else {
		//If it does exist, lets get the items from the session storage and place them in our array variable
		donatedItems = JSON.parse(window.sessionStorage.getItem("DonatedItems"));
	}

	donatedItems.push({ name: txtDonateItem.value});
	window.sessionStorage.setItem("DonatedItems", JSON.stringify(donatedItems));

	showdemo(e);
}

function donateItemFromCart(e){
	e.preventDefault();

	var cbxDonateItem = document.getElementById('cbxDonateItem');
	if (cbxDonateItem.value == ''){
		alert('Please select the item you want to donate');	
		return;
	}

	var cart = [];
	if (window.sessionStorage.getItem("UserCart") == null){
		return;
	} else {
		cart = JSON.parse(window.sessionStorage.getItem("UserCart"));
	}

	var cartItem = cart.find(where => where.itemName == cbxDonateItem.value);

	var quantity = prompt('How many do you want to donate of the following item: ' + cartItem.itemName);
	if (quantity != null && quantity != undefined && quantity != ""){
		if (quantity == parseInt(quantity)){
			if (parseInt(quantity) > cartItem.qty){
				alert('You cannot donate more than the quantity you have in your cart: ' +cartItem.qty);
				return;
			}

			var htmlTemplate = '<div class="col-sm-4" style="text-align: center; border: 1px solid black; border-radius: 5px;padding:20px ;margin: 20px; background-color: white; width: 500px; height: 200px"><a href="javascript:claimDonatedItem(\'$itemName$\');"><img class="thumbpic" src="images/donate.png"><h3>$itemName$</h3></a></div>';

			var parentDiv = document.getElementById("parent-div");

			var fullItemName = quantity.toString() + " x " + cbxDonateItem.value;

			parentDiv.innerHTML += htmlTemplate.replaceAll('$itemName$', fullItemName);

			//Create an empty array variable which will be out array of donated items
			var donatedItems = [];

			//This IF checks if the session storage named "DonatedItems" already exists
			if (window.sessionStorage.getItem("DonatedItems") == null){
				//If it doesn't exist, lets create it and just set it to empty for now
				window.sessionStorage.setItem("DonatedItems", JSON.stringify([]));
			} else {
				//If it does exist, lets get the items from the session storage and place them in our array variable
				donatedItems = JSON.parse(window.sessionStorage.getItem("DonatedItems"));
			}

			donatedItems.push({ name: fullItemName});
			window.sessionStorage.setItem("DonatedItems", JSON.stringify(donatedItems));	
		} else {
			alert('Please enter a number');
		}
	}

	showdemo(e);
}

//var cart = window.sessionStorage.getItem("UserCart");
	//if (cart != null){
		//cart = JSON.parse(window.sessionStorage.getItem("UserCart"));	

		//var parentDiv = document.getElementById("cartItems");
		//var template = '<h5>$itemName$</h5><p>Quantity: $itemQuantity$</p><hr>';

		//for (var item in cart){
		//	var currentItem = cart[item];

			//parentDiv.innerHTML += template.replace("$itemName$", currentItem.itemName).replace//("$itemQuantity$", currentItem.qty);
		//}
	//}

function seachFood(e){
	e.preventDefault();

	var parentDiv = document.getElementById("parent-div");
	parentDiv.innerHTML = "";

	var htmlTemplate = '<div class="col-sm-4" style="text-align: center; border: 1px solid black; border-radius: 5px;padding:20px ;margin: 20px; background-color: white; width: 500px; height: 200px"><a href="javascript:addToCart(\'$groceryName$\');"><img class="thumbpic" src="images/groceries vegetable.png"> <h3>$groceryName$</h3><p><i>$groceryCalories$ calories</i></p></a></div>';

	var searchWords = document.getElementById("search").value.split(",");
	for (var searchWord in searchWords){
		var settings = {
			"url": "https://edamam-food-and-grocery-database.p.rapidapi.com/parser?ingr=" + searchWords[searchWord].trim(),
			"method": "GET",
			"timeout": 0,
			"headers": {
				"x-rapidapi-key": "33179136b2mshc66e07cecd059ddp130dbbjsn54a479c20abd",
				"x-rapidapi-host": "edamam-food-and-grocery-database.p.rapidapi.com"
			},
		};

		$.ajax(settings).done(function (response) {
			console.log(response);
			var currentFood = response.parsed[0];
			if (currentFood != undefined){
				parentDiv.innerHTML += htmlTemplate.replaceAll("$groceryName$", currentFood.food.label.toUpperCase()).replace("$groceryCalories$", currentFood.food.nutrients.ENERC_KCAL);
			}
		});
	}

	showdemo(e);
}

//<div class="col-md-4" style="border: 1px solid black; border-radius: 5px;padding: 20px; margin: 20px; background-color: white; width: 500px; height: 200px">
  //      <h5>Food Bank A</h5>
    //    <p><i>Produce</i></p>
      //  <p>1234 Cherry Jane Lane, Sacramento, CA, 61592</p>
        //<p>+1(949)-677-0089</p>
      //</div>

function searchFoodbank(e){
	e.preventDefault();
	
	if (navigator.geolocation) {
    navigator.geolocation.getCurrentPosition(continueSearchFood);
  } else { 
    alert("Geolocation is not supported by this browser.");
  }

	showdemo(e);
}

function continueSearchFood(position){
	position.coords.latitude + "," + position.coords.longitude
}

function createAndShowMap(){
	if (navigator.geolocation) {
    navigator.geolocation.getCurrentPosition(initMap);
  } else { 
    alert("Geolocation is not supported by this browser.");
  }	
}

var map;
var service;
var infowindow;

function initMap(position) {
  var browserPosition = new google.maps.LatLng(position.coords.latitude, position.coords.longitude);

  infowindow = new google.maps.InfoWindow();

  map = new google.maps.Map(
      document.getElementById('map'), {center: browserPosition, zoom: 12});

	var request = {
    location: browserPosition,
    radius: '10000',
		keyword: 'foodbank',
    type: ["point_of_interest", "establishment"]
  };

  var service = new google.maps.places.PlacesService(map);

  service.nearbySearch(request, function(results, status) {
    if (status === google.maps.places.PlacesServiceStatus.OK) {
			console.log(results);
      for (var i = 0; i < results.length; i++) {
        createMarker(results[i]);
      }
      map.setCenter(results[0].geometry.location);
    }
  });
}

function createMarker(place) {
  const marker = new google.maps.Marker({
    map,
    position: place.geometry.location,
  });
  google.maps.event.addListener(marker, "click", () => {
    infowindow.setContent(place.name);
    infowindow.open(map);
  });
}

function addToCart(item){
	var cart = [];
	if (window.sessionStorage.getItem("UserCart") == null){
		window.sessionStorage.setItem("UserCart", JSON.stringify([]));
	} else {
		cart = JSON.parse(window.sessionStorage.getItem("UserCart"));
	}

	var quantity = prompt('How many do you want to add to the cart of the following item: ' + item);
	if (quantity != null && quantity != undefined && quantity != ""){
		if (quantity == parseInt(quantity)){
			cart.push({itemName: item, qty: quantity});	
			window.sessionStorage.setItem("UserCart", JSON.stringify(cart))
			alert('Item successfully added to cart');
		} else {
			alert('Please enter a number');
		}
	}
}

function showdemo(e) {
  e.preventDefault();

  let element = document.getElementById("hidden-content");
      element.classList.remove("hidden");


      let ele = document.getElementById("my-form");

			try{
				ele.reset();
			} catch { }


      setTimeout(
                  function () {
                      var element = document.getElementById("hidden-content");

                      element.scrollIntoView({ behavior: "smooth" });

                      let element1 = document.getElementById("warning");
                      element1.classList.add("hidden");
                  }
                  , 300);
}

function checkoutshow(e) {
  e.preventDefault();

  let element = document.getElementById("hidden-content");
      element.classList.remove("hidden");


      setTimeout(
                  function () {
                      var element = document.getElementById("hidden-content");

                      element.scrollIntoView({ behavior: "smooth" });
                  }
                  , 300);

}