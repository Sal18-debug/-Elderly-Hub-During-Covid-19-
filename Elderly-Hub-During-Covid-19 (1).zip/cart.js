window.onload=function(){
	var cart = window.sessionStorage.getItem("UserCart");
	if (cart != null){
		cart = JSON.parse(window.sessionStorage.getItem("UserCart"));	

		var parentDiv = document.getElementById("cartItems");
		var template = '<h5>$itemName$</h5><p>Quantity: $itemQuantity$</p><hr>';

		for (var item in cart){
			var currentItem = cart[item];

			parentDiv.innerHTML += template.replace("$itemName$", currentItem.itemName).replace("$itemQuantity$", currentItem.qty);
		}
	}
}