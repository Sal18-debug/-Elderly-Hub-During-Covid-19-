var map;
var service;
var infowindow;
var browserPosition;

function createAndShowMap(){
	if (navigator.geolocation) {
    navigator.geolocation.getCurrentPosition(initMap);
  } else { 
    alert("Geolocation is not supported by this browser.");
  }	
}

function initMap(position) {
  browserPosition = new google.maps.LatLng(position.coords.latitude, position.coords.longitude);

  infowindow = new google.maps.InfoWindow();

  map = new google.maps.Map(
      document.getElementById('map'), {center: browserPosition, zoom: 12});
}

function searchResturaunt(e){
	e.preventDefault();

	var txtSearch = document.getElementById('txtSearch');

	var request = {
    location: browserPosition,
    radius: '10000',
		keyword: txtSearch.value,
    type: ['restaurant']
  };

  var service = new google.maps.places.PlacesService(map);

	var parentDiv = document.getElementById('divParent');

	var htmlTemplate = '<div class="col-lg-4 content-box" style="text-align: center; border: 1px solid black; border-radius: 5px;padding: 20px; margin: 20px; background-color: white; width: 500px; height: 200px"><a href="javascript:placeOrder(\'$placeName$\')"><img class="thumbpic" src= "$placePhoto$"><h3>$placeName$</h3><p><i>$placeAddress$</i></p></a></div>';

  service.nearbySearch(request, function(results, status) {
    if (status === google.maps.places.PlacesServiceStatus.OK) {
			console.log(results);
      for (var i = 0; i < results.length; i++) {
        createMarker(results[i]);
				parentDiv.innerHTML += htmlTemplate.replaceAll("$placeName$", results[i].name.replaceAll("'", "")).replaceAll("$placeAddress$", results[i].vicinity).replaceAll("$placePhoto$", results[i].photos[0].getUrl());
      }
      map.setCenter(results[0].geometry.location);
    }
  });

	showdemo(e);
}

var speechRecognition;

function placeOrder(restName){
	alert('After you click OK on this message, your browser will start recording, please speak your order into your microphone for resturaunt: ' + restName);

	speechRecognition = new webkitSpeechRecognition();
	speechRecognition.onresult = speechComplete;
	speechRecognition.start();
}

function speechComplete(result){
	var order = result.results[0];
	if (order != null){
		var orderConfirmed = confirm('Is this what you would like to order: ' + result.results[0][0].transcript);
		if (orderConfirmed){
			addToCart(result.results[0][0].transcript);
			alert('Order added to cart successfully');
		}
	} else {
		alert('We were unable to understand your order, please try again');
	}
}

function createMarker(place) {
  const marker = new google.maps.Marker({
    map,
    position: place.geometry.location,
  });
  google.maps.event.addListener(marker, "click", () => {
    infowindow.setContent(place.name);
    infowindow.open(map);
  });
}

function addToCart(item){
	var cart = [];
	if (window.sessionStorage.getItem("UserCart") == null){
		window.sessionStorage.setItem("UserCart", JSON.stringify([]));
	} else {
		cart = JSON.parse(window.sessionStorage.getItem("UserCart"));
	}

	cart.push({itemName: item, qty: 1});	
	window.sessionStorage.setItem("UserCart", JSON.stringify(cart))
}

function showdemo(e) {
  e.preventDefault();

  let element = document.getElementById("hidden-content");
      element.classList.remove("hidden");


      let ele = document.getElementById("my-form");

			try{
				ele.reset();
			} catch { }


      setTimeout(
                  function () {
                      var element = document.getElementById("hidden-content");

                      element.scrollIntoView({ behavior: "smooth" });

                      let element1 = document.getElementById("warning");
                      element1.classList.add("hidden");
                  }
                  , 300);
}