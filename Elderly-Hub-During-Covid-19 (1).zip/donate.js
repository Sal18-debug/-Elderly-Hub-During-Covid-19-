window.onload=function(){
	//When the page loads, we want to check if our session storage exists, if it does, continue, else nothing happens
	if (window.sessionStorage.getItem("DonatedItems") != null){
		//Since the session storage exists, get all the items from the storage and assign them to a variable
		var donatedItems = JSON.parse(window.sessionStorage.getItem("DonatedItems"));

		//This is our HTML template
		var htmlTemplate = '<div class="col-sm-4" style="text-align: center; border: 1px solid black; border-radius: 5px;padding:20px ;margin: 20px; background-color: white; width: 500px; height: 200px"><a href="javascript:claimDonatedItem(\'$itemName$\');"><img class="thumbpic" src="images/donate.png"><h3>$itemName$</h3></a></div>';

		//This variable is our DIV in which we will display the donated items
		var parentDiv = document.getElementById("parent-div");

		//Loop through all donated items
		for (var item in donatedItems){
			parentDiv.innerHTML += htmlTemplate.replaceAll('$itemName$', donatedItems[item].name);
		}
	}

		var cart = window.sessionStorage.getItem("UserCart");
		if (cart != null){
			cart = JSON.parse(window.sessionStorage.getItem("UserCart"));	

			var cbxItems = document.getElementById('cbxDonateItem');

			for (var item in cart){
				var option = document.createElement("option");
				option.text = cart[item].itemName;
				cbxItems.add(option);
			}
		}
}